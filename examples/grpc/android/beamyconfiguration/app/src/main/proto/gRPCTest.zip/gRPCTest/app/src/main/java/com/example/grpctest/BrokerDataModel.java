package com.example.grpctest;

import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Log;
import android.widget.ArrayAdapter;

import java.util.List;
import java.util.Observable;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

public class BrokerDataModel extends Observable {

    private ManagedChannel channel;
    private String[] list = null;
    private ArrayAdapter<String> adapter = null;

    private boolean done;
    private String serverAdress;
    private int port;

    private  List<Base.NetworkInfo> listan = null;

    public BrokerDataModel() {

    }

    private int parsePort(String serverA){
        Log.println(Log.INFO,serverA,"this is it");

        try{
            return Integer.parseInt(serverA);
        }catch(NumberFormatException ex){
            Log.println(Log.INFO,"PORTERROR:",ex.toString());
        }

        return -1;
    }

    public void connect(String serverAdr){

        done = false;
        try {
            this.serverAdress = serverAdr.substring(0, serverAdr.lastIndexOf(":"));
            this.port = parsePort(serverAdr.substring(serverAdr.lastIndexOf(":")+1, serverAdr.length()));

            new LongOperation().execute("");

        }catch(Exception ex){
            Log.println(Log.ERROR," could not parse url ", ex.toString());
        }
    }

    public String[] getSignalList() {
        if (done == true) {
            done  = false;
            return list;
        }
        return null;
    }

    private class LongOperation extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {

            if (port > -1) {
                try {
                    channel = ManagedChannelBuilder.forAddress(serverAdress, 50051).usePlaintext().build();
                    SystemServiceGrpc.SystemServiceStub stub = SystemServiceGrpc.newStub(channel);
                    SystemServiceGrpc.SystemServiceBlockingStub stub1 = SystemServiceGrpc.newBlockingStub(channel);

                    //stub1.
                    Base.Empty request = Base.Empty.newBuilder().build();
                    System.Configuration conf = stub1.getConfiguration(request);

                    listan = conf.getNetworkInfoList();

                    //List<Base.Frames> signals = stub1.listSignals(namespace);

                    list = new String[listan.size()];

                    int index = 0;
                    for (Base.NetworkInfo i : listan) {
                        // Retrieve information on current vehicle setup.

                        String description = i.getDescription();
                        String typeStr = i.getType();
                        // list all signals per namespace
                        String namespacename =  i.getNamespace().getName();
                        Base.Frames signals = stub1.listSignals(i.getNamespace());
                        // log frame names per namespace
                        Log.println(Log.INFO, "signals", namespacename);
                        for (int findex = 0; findex < signals.getFrameCount(); findex++) {
                            Log.println(Log.INFO, "SIG: ", signals.getFrame(findex).getSignalInfo().getId().getName());
                        }

                        list[index] = typeStr + " " + namespacename + " " + description;

                        index++;



                    }

                    done = true;
                }catch(Exception ex){
                    Log.println(Log.ERROR,"gRPC connection", "could not connect to " + serverAdress + ":" + port);
                }
            }
            return "Executed";
        }

        @Override
        protected void onPostExecute(String result) {
            // adapter.notifyDataSetChanged();
            notifyObservers();
        }

        @Override
        protected void onPreExecute() {}

        @Override
        protected void onProgressUpdate(Void... values) {

        }
    }

}

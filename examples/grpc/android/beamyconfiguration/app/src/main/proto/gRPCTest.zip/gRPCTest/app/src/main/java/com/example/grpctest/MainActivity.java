package com.example.grpctest;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import io.grpc.ManagedChannelBuilder;

import io.grpc.ManagedChannel;

import java.util.List;
import java.util.Observable;
import java.util.Observer;

public class MainActivity extends AppCompatActivity implements Observer, View.OnClickListener {


    private ListView listview;
    private ArrayAdapter<String> adapter = null;

    private BrokerDataModel aModel;

    private Button connectButton;
    private TextView serverAdr;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        serverAdr = findViewById(R.id.beamyurl);
        connectButton = findViewById(R.id.connectbutton);

        aModel = new BrokerDataModel();
        aModel.addObserver(this);

        Log.println(Log.INFO,"onCreate", "done");

    }

    @Override
    public void update(Observable o, Object arg) {
        Log.println(Log.INFO,"update triggered",o.toString());

        String[] listan = aModel.getSignalList();
        for (String element : listan){
            Log.println(Log.INFO,"data-output-from-beamy-",element);
        }

    }

    @Override
    public void onClick(View v) {

        Log.println(Log.INFO,"clicked in window",v.toString());

        switch(v.getId()){
            case R.id.connectbutton:
                aModel.connect(serverAdr.getText().toString());
                break;
        }
    }


}
